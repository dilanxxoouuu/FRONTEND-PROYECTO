import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import './ShoppingCart.css';



const ShoppingCart = () => {
    const cartListRef = useRef(null);
    const [cartHeight, setCartHeight] = useState(0);
    const [cartItems, setCartItems] = useState([]);
    const [recommendedProducts, setRecommendedProducts] = useState([]);
    const [total, setTotal] = useState(0);
    const [loading, setLoading] = useState(true);
    const recommendedSectionRef = useRef(null);
    const [error, setError] = useState(null);
    const [userDetails, setUserDetails] = useState({ nombre: '', direccion: '', telefono: '' });
    const [showModal, setShowModal] = useState(false);
    const [paymentSuccess, setPaymentSuccess] = useState(false);
    const [paymentMethod, setPaymentMethod] = useState('');
    const [carritoId, setCarritoId] = useState(null);

    const getAuthHeaders = () => {
        const token = localStorage.getItem("token");
        return token ? { Authorization: `Bearer ${token}` } : null;
    };

    const fetchCart = async () => {
        try {
            const headers = getAuthHeaders();
            if (!headers) return;

            const response = await axios.get('http://localhost:5000/carrito/activo', { headers });
            const carrito = response.data;
            setCarritoId(carrito.id_carrito);
            setCartItems(carrito.productos || []);
            calculateTotal(carrito.productos);
        } catch (err) {
            console.error(err);
            setError("Error al cargar el carrito");
        } finally {
            setLoading(false);
        }
    };

    const updateQuantity = async (productId, newQuantity) => {
        if (!carritoId || newQuantity < 0) return;

        const headers = getAuthHeaders();

        if (newQuantity === 0) {
            await removeFromCart(productId);
            return;
        }

        try {
            await axios.put(`http://localhost:5000/carrito/${carritoId}/producto`, {
                id_producto: productId,
                cantidad: newQuantity
            }, { headers });

            const updatedItems = cartItems.map(item =>
                item.id_producto === productId ? { ...item, cantidad: newQuantity } : item
            );
            setCartItems(updatedItems);
            calculateTotal(updatedItems);
        } catch (err) {
            console.error("Error actualizando cantidad", err);
        }
    };

    const fetchRecommendedProducts = async () => {
        try {
            const response = await axios.get("http://localhost:5000/productos");
            setRecommendedProducts(response.data);
        } catch (err) {
            console.error("Error al obtener productos recomendados", err);
        }
    };
    
    
    useEffect(() => {
        fetchCart();
        fetchRecommendedProducts();
    }, []);

    useEffect(() => {
        if (cartListRef.current) {
            const height = cartListRef.current.clientHeight;
            setCartHeight(height);
        }
    }, [cartItems]);
    

    const removeFromCart = async (productId) => {
        if (!carritoId) return;

        try {
            const headers = getAuthHeaders();
            await axios.delete(`http://localhost:5000/carrito/${carritoId}/producto`, {
                headers,
                data: { id_producto: productId } // <--- axios lo permite, pero no todos los backends lo interpretan bien
            });
            

            const updatedItems = cartItems.filter(item => item.id_producto !== productId);
            setCartItems(updatedItems);
            calculateTotal(updatedItems);
        } catch (err) {
            console.error("Error eliminando producto", err);
        }
    };

    const calculateTotal = (items) => {
        const totalPrice = items.reduce((sum, item) => {
            const precio = Number(item.producto_precio) || 0;
            const cantidad = Number(item.cantidad) || 1;
            return sum + (precio * cantidad);
        }, 0);
        setTotal(totalPrice);
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setUserDetails({ ...userDetails, [name]: value });
    };

    const validateForm = () => {
        return userDetails.nombre && userDetails.direccion && userDetails.telefono;
    };

    const proceedToPayment = () => {
        if (!validateForm()) return alert("Rellene todos los campos del formulario.");
        if (!paymentMethod) return alert("Seleccione un método de pago.");
        setPaymentSuccess(true);
    };

    const closeModal = () => {
        setShowModal(false);
        setUserDetails({ nombre: '', direccion: '', telefono: '' });
        setPaymentSuccess(false);
        setPaymentMethod('');
    };

    const handlePaymentMethodChange = (e) => {
        setPaymentMethod(e.target.value);
    };

    useEffect(() => {
        fetchCart();
    }, []);

    if (loading) return <p>Cargando carrito...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div className="container">
            <div className="cart-list" ref={cartListRef}>

                <h2>Carrito de Compras</h2>
                {cartItems.map((product) => (
                    <div className="cart-item" key={product.id_producto}>
                        <img
                            src={`http://localhost:5000/static/uploads/${product.producto_foto}`}
                            alt={product.producto_nombre}
                        />
                        <div className="cart-info">
                            <h4>{product.producto_nombre}</h4>
                            <p className="description">{product.descripcion}</p>
                            <div className="price">${new Intl.NumberFormat('es-CL').format(product.producto_precio)}</div>
                        </div>
                        <div className="cart-controls">
                            <div className="quantity-controls">
                                <button onClick={() => updateQuantity(product.id_producto, product.cantidad - 1)}>-</button>
                                <span>{product.cantidad}</span>
                                <button onClick={() => updateQuantity(product.id_producto, product.cantidad + 1)}>+</button>
                            </div>
                            <button className="remove-btn" onClick={() => removeFromCart(product.id_producto)}>Eliminar</button>
                        </div>
                    </div>
                ))}
            </div>

            <div className="cart-summary">
                <div>
                    <h3>Total: ${new Intl.NumberFormat().format(total)}</h3>
                    <button onClick={() => setShowModal(true)}>Ir a Pagar</button>
                </div>

                {recommendedProducts.length > 0 && (
                    <div className="recommended-section">
                        <h4>También te puede interesar</h4>
                        <div className="recommended-products">
                            {recommendedProducts.map((product) => (
                                <div className="recommended-card" key={product.id_producto}>
                                    <img
                                        src={`http://localhost:5000/static/uploads/${product.producto_foto}`}
                                        alt={product.producto_nombre}
                                    />
                                    <div className="recommended-info">
                                        <p className="recommended-name">{product.producto_nombre}</p>
                                        <p className="recommended-price">
                                            ${new Intl.NumberFormat('es-CL').format(product.producto_precio)}
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                )}

            </div>


            {showModal && (
                <div className="modal">
                    <div className="modal-content">
                        <div className="modal-header">
                            <span className="close" onClick={closeModal}>&times;</span>
                        </div>
                        {!paymentSuccess ? (
                            <div>
                                <h3>Rellene sus datos</h3>
                                <form onSubmit={(e) => e.preventDefault()}>
                                    <input type="text" name="nombre" placeholder="Nombre" value={userDetails.nombre} onChange={handleInputChange} />
                                    <input type="text" name="direccion" placeholder="Dirección" value={userDetails.direccion} onChange={handleInputChange} />
                                    <input type="text" name="telefono" placeholder="Teléfono" value={userDetails.telefono} onChange={handleInputChange} />
                                    <select value={paymentMethod} onChange={handlePaymentMethodChange}>
                                        <option value="">Seleccione método de pago</option>
                                        <option value="tarjeta">Tarjeta</option>
                                        <option value="efectivo">Efectivo</option>
                                    </select>
                                    <button onClick={proceedToPayment}>Realizar Pago</button>
                                </form>
                            </div>
                        ) : (
                            <div className="payment-success">
                                <h3>¡Pago exitoso!</h3>
                                <p>Gracias por su compra.</p>
                                <button onClick={closeModal}>Cerrar</button>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};

export default ShoppingCart;
